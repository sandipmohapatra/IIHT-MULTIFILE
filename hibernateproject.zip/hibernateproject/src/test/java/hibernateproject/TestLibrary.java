package hibernateproject;
import static org.mockito.Mockito.when;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.Before;
import org.junit.Test;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import com.cognizant.repository.*;
import com.cognizant.model.*;
import com.cognizant.*;
  import org.hibernate.*;
      public class TestLibrary  
    {
       
    @Test
    public void addSubject() 
    {	
    	Subject subject = new Subject();
			assertNotNull(subject);
			}
    
    @Test
    public void deleteSubject() {
		int subjectId=1;
		assertNotNull(subjectId);
			}

    @Test
	public void searchSubject() {
		int subjectId=1;
		assertNotNull(subjectId);
			}
	
@Test
	public void addBook() {	
		Book book = new Book();		
		assertNotNull(book);
		}
	
@Test
	public void deleteBook() 
{
		int bookId=1;
		assertNotNull(bookId);
			}
	
@Test
	public void searchBook() {
		int bookId=1;
		assertNotNull(1);
		}

	public String gatValFromConsole(String log)
	{
		System.out.println(log);
		String inputString = "";
		try {
			BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			inputString = bufferRead.readLine();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return inputString;
	}
	
}

//mock the session and session factory


