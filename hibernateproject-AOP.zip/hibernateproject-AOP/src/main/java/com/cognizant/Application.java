package com.cognizant;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import com.cognizant.model.Book;
import com.cognizant.model.Subject;
import com.cognizant.repository.EntityDao;
import com.cognizant.repository.EntityDaoImpl;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Aspect
public class Application {
	private EntityDao entityDao;

	Application() {
		this.entityDao = new EntityDaoImpl();
		while (true) {
			System.out.println("\n");
			System.out.println("1.Add a Subject");
			System.out.println("2.Add a Book");
			System.out.println("3.Delete a Subject");
			System.out.println("4.Delete a book");
			System.out.println("5.Search for a subject");
			System.out.println("6.Search for a book");
			System.out.println("7.Exit");
			String input = gatValFromConsole("please select menu items::::::::::::::::");
			select(Integer.parseInt(input));
		}
	}
	
	public static void main(String[] args) 
	{	
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Operation e = (Operation) context.getBean("opBean");
		e.msg();
		e.display();
		new Application();
	}
	
	public void select(int i) {
		switch(i) {
		case 1: entityDao.addSubject(addSubject());
		break;
		case 2: entityDao.addBook(addBook());
		break;
		case 3: entityDao.deleteSubject(deleteSubject());
		break;
		case 4: entityDao.deleteBook(deleteBook());
		break;
		case 5: Subject subject=entityDao.searchSubject(searchSubject());
				System.out.println("Result :"+subject);
		break;
		case 6: Book book=entityDao.searchBook(searchBook());
				System.out.println("Result :"+book);
		break;
		case 7: exit();
		break;
		}	
	}

	@Pointcut("execution(* Operation.*(..))")
	private Subject addSubject() {	
		Subject subject = new Subject();
		subject.setSubjectId(1);
		subject.setSubTitle("java");
		subject.setDurationInHours(4);
		System.out.println(subject.toString());
		return subject;
	}
	
	@Pointcut("execution(* Operation.*(..))")
	private long deleteSubject() {
		long subjectId=Long.parseLong(gatValFromConsole("Enter the subject id to be deleted"));
		return subjectId;
	}

	@Pointcut("execution(* Operation.*(..))")
	private long searchSubject() {
		long subjectId=Long.parseLong(gatValFromConsole("Enter the subject id for search"));
		return subjectId;
	}
	
	@Pointcut("execution(* Operation.*(..))")
	private Book addBook() {	
		Book book = new Book();		
		book.setBookId(Long.parseLong(gatValFromConsole("Enter book id")));
		book.setTitle(gatValFromConsole("Enter book title"));
		book.setPrice(Integer.parseInt(gatValFromConsole("Enter book price")));
		book.setVolume(Integer.parseInt(gatValFromConsole("Enter book volume")));
		book.setPublishDate(gatValFromConsole(gatValFromConsole("Enter book publish date(yyyy-mm-dd(2022-01-01)) ")));
		System.out.println(book.toString());
		return book;
	}
	
	@Pointcut("execution(* Operation.*(..))")
	private long deleteBook() {
		long bookId=Long.parseLong(gatValFromConsole("Enter the book id to be deleted"));
		return bookId;
	}
	
	@Pointcut("execution(* Operation.*(..))")
	private long searchBook() {
		long bookId=Long.parseLong(gatValFromConsole("Enter the book id for search "));
		return bookId;
	}


	private String gatValFromConsole(String log) {
		System.out.println(log);
		String inputString = "";
		try {
			BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			inputString = bufferRead.readLine();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return inputString;
	}
	
	@Around("searchBook()")
	public Object myAdvice1(ProceedingJoinPoint jp)throws Throwable 
	{
		System.out.println("concern before calling actual method");
		Object obj=jp.proceed();
		System.out.println("concern after calling actual method");
		return obj;
		
	}
	
	@Around("addSubject()")
	public Object myAdvice(ProceedingJoinPoint jp)throws Throwable 
	{
		System.out.println("concern before calling actual method");
		Object obj=jp.proceed();
		System.out.println("concern after calling actual method");
		return obj;
		
	}
	private void exit() {
		System.exit(0);
	}
	
}
