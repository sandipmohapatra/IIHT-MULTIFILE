package com.cognizant;

public class Operation {
public void msg()
{
	System.out.println("execution  is invoked");
}
public void display()
{
	System.out.println("DAO method() is invoked");
}
}
