package hibernateproject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Before;
import org.junit.Test;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import static org.junit.Assert.*;
import com.cognizant.model.*;
import com.cognizant.repository.EntityDao;
import com.cognizant.repository.EntityDaoImpl;

      public class TestLibrary  
    {
    	  private EntityDao entityDao;
    	  public TestLibrary()
    	  {
    	  this.entityDao = new EntityDaoImpl();
    	  }
    	  
    	  @Test
    	  public void testAddSubject()
    	  {
    		  entityDao.addSubject(addSubject());
    		  assertNotNull(entityDao);
    	  }
    	  
    	  
    	  @Test
    	  public void testAddBook()
    	  {
    		  entityDao.addBook(addBook());
    		  assertNotNull(entityDao);
    	  }
    	  
    	  @Test
    	  public void testSearchSubject()
    	  {
    		  Subject subject=entityDao.searchSubject(searchSubject());
    		  assertNotNull(subject);
    	  }
    	  
    	  @Test
    	  public void testSearchBook()
    	  {
    		  Book book=entityDao.searchBook(searchBook());
    		  assertNotNull(book);
    	  }
    	  
    	  @Test
    	  public void testDeleteSubject()
    	  {
    		  entityDao.deleteSubject(deleteSubject());
    		  assertNotNull(entityDao);
    	  }
    	  
    	  
    	  
    	  
    	  private Subject addSubject() {	
    			Subject subject = new Subject();
    			subject.setSubjectId(2);
    			subject.setSubTitle("core java");
    			subject.setDurationInHours(4);
    			System.out.println(subject.toString());
    			return subject;
    		}
    
    	  
    	  private long searchSubject() {
    			long subjectId=4;
    			return subjectId;
    		}
    		

    		private Book addBook() {	
    			Book book = new Book();		
    			book.setBookId(101);
    			book.setTitle("Microservice");
    			book.setPrice(500);
    			book.setVolume(1);
    			book.setPublishDate("2022-01-01");
    			System.out.println(book.toString());
    			return book;
    		}
    		

    		private long deleteBook() {
    			long bookId=1;
    			return bookId;
    		}
    		
    		private long deleteSubject() {
    			long subjectId=2;
    			return subjectId;
    		}

    		private long searchBook() {
    			long bookId=1;
    			return bookId;
    		}
    	
    }

