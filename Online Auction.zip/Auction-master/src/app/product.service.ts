import { Injectable } from '@angular/core';
//import { product } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  

  constructor() { }
}
