export class Product{
    id?:number;
    name?:string;
    specification?:string; 
    cat?:string   

}