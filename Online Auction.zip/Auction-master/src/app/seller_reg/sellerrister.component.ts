import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller_reg',
  templateUrl: './sellerrister.component.html',
  styleUrls: ['./sellerrister.component.css']
})
export class SellerristerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
