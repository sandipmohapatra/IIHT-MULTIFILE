export class Customer {
    customer_id!: number;
    customer_name!: string;
    category!:string;
    product_id!:number;
    bidding_price!: number;
}
