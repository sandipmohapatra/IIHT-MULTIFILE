export class Registration {
    first_name!: string;
    last_name!: string;
    age!:number;
    role!: string;
    phone!:number;
    email!:string;
    password!: string;
    confirm_password!: string;
}
