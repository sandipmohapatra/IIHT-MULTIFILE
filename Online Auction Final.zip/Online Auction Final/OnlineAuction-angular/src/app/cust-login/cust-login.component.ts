import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-login',
  templateUrl: './cust-login.component.html',
  styleUrls: ['./cust-login.component.css']
})
export class CustLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
